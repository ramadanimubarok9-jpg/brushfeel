# MY WORLD

A small personal Android app prototype with the opening tagline:

**Your life. Your ideas. Your own creation.**

## Build APK with GitHub Actions
1. Create a GitHub repository named `my-world`.
2. Upload the contents of this project (the files inside this ZIP, not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build MY WORLD APK** and press **Run workflow** (or push to `main`).
5. Open the successful workflow run and download the `MY-WORLD-APK` artifact.
6. Extract the ZIP artifact to get `app-debug.apk`.

This is an early prototype. MY LIFE, MY CREATION, and MY MIND each have a local note field. Notes are saved on the device only.
