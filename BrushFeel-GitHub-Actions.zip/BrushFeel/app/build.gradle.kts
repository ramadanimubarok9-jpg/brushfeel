plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android { namespace = "com.danii.brushfeel"; compileSdk = 35
    defaultConfig { applicationId = "com.danii.brushfeel"; minSdk = 34; targetSdk = 35; versionCode = 1; versionName = "0.1" }
}
