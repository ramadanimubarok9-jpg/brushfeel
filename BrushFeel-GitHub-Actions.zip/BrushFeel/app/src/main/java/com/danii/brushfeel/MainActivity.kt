package com.danii.brushfeel

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,48,32,32) }
        root.addView(TextView(this).apply { text = "Brush Feel\n\nPrototype: suara gesekan real-time saat jari bergerak.\n\n1. Aktifkan layanan di Accessibility.\n2. Kembali ke IbisPaint.\n3. Nyalakan layanan dan coba gambar."; textSize = 18f })
        root.addView(Button(this).apply { text = "Buka Accessibility"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        root.addView(TextView(this).apply { text = "Volume"; textSize = 16f })
        root.addView(SeekBar(this).apply { max = 100; progress = 35; setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s: SeekBar?, p: Int, f: Boolean) { getPreferences(0).edit().putInt("volume", p).apply() }; override fun onStartTrackingTouch(s: SeekBar?) {}; override fun onStopTrackingTouch(s: SeekBar?) {} }) })
        setContentView(root)
    }
}
