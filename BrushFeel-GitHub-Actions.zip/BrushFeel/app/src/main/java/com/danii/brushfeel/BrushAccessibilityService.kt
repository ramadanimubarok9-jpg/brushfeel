package com.danii.brushfeel

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.view.InputDevice
import android.view.MotionEvent
import kotlin.math.abs
import kotlin.math.min
import kotlin.random.Random

class BrushAccessibilityService : AccessibilityService() {
    private var audio: AudioTrack? = null
    private var playing = false
    private var lastX = 0f
    private var lastY = 0f
    private var lastT = 0L
    private var speed = 0f
    @Volatile private var alive = true

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (Build.VERSION.SDK_INT >= 34) {
            val info = serviceInfo
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_SEND_MOTION_EVENTS
            info.setMotionEventSources(InputDevice.SOURCE_TOUCHSCREEN)
            serviceInfo = info
        }
        startAudio()
    }

    private fun startAudio() {
        val sr = 44100
        val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        audio = AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()).setBufferSizeInBytes(min * 2).setTransferMode(AudioTrack.MODE_STREAM).build()
        audio?.play()
        Thread {
            val buf = ShortArray(1024)
            var state = 0f
            while (alive) {
                val active = playing
                val amp = if (active) min(0.18f, 0.025f + speed * 0.0035f) else 0f
                for (i in buf.indices) {
                    val n = Random.nextFloat() * 2f - 1f
                    state = state * 0.92f + n * 0.08f
                    buf[i] = (state * amp * Short.MAX_VALUE).toInt().toShort()
                }
                audio?.write(buf, 0, buf.size)
            }
        }.start()
    }

    override fun onMotionEvent(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastX = event.x; lastY = event.y; lastT = event.eventTime; speed = 0f; playing = false }
            MotionEvent.ACTION_MOVE -> {
                val dt = (event.eventTime - lastT).coerceAtLeast(1L)
                val dx = event.x - lastX; val dy = event.y - lastY
                val pxPerMs = kotlin.math.sqrt(dx*dx + dy*dy) / dt
                speed = speed * 0.65f + pxPerMs * 0.35f
                playing = abs(dx) + abs(dy) > 0.5f
                lastX = event.x; lastY = event.y; lastT = event.eventTime
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { playing = false; speed = 0f }
        }
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() { playing = false }
    override fun onDestroy() { alive = false; playing = false; audio?.stop(); audio?.release(); audio = null; super.onDestroy() }
}
